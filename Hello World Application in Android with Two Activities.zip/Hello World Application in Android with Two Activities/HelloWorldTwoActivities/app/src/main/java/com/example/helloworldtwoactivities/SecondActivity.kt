package com.example.helloworldtwoactivities

import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.textfield.TextInputEditText

class SecondActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)

        val button = findViewById<Button>(R.id.buttonSecond)
        val editText = findViewById<TextInputEditText>(R.id.editTextSecond)
        val imageView = findViewById<ImageView>(R.id.imageSecond)

        button.setOnClickListener {
            val input = editText.text.toString()
            Toast.makeText(this, "Welcome, $input!", Toast.LENGTH_SHORT).show()
        }
    }
}
